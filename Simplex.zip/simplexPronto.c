// WILLIAN PITTER CARDOSO LIMA
#include <stdlib.h>
#include <stdio.h>
 #include<unistd.h> 
int max = 0;


float **multiplica(int m1,int n1,int m2,int n2,float** matriz1,float** matriz2){

	int i=0,j=0,k=0; 	

	float **mk; // Matriz invertida que será retornada.
  	 mk = malloc (m1 * sizeof (float *));
   	for (i = 0; i < n1; ++i)
    	  mk[i] = malloc (m2 * sizeof (float));


	for(i=0;i<m1;i++){	// inicializa com 0		
		for(j=0;j<n2;j++){		
			mk[i][j] = 0;
		}
	}	
	for(i=0;i<m1;i++){	// multiplica a matriz
		for(j=0;j<n2;j++){
			for(k=0;k<n1;k++){
				mk[i][j]= mk[i][j] + (matriz1[i][k] * matriz2[k][j]);
			}
		}
	}


	

	return mk;
	
	
}

float **inverte(int m,int n,float** matriz){
	int i=0,j=0,k=0,p=0,t=0,y;
	float pivo=0,a=0,b=0,c=0;
	float l1[n];
	float l2[n];
	float inv1[n];
	float inv2[n];

	float **invertida; 
  	invertida = malloc (sizeof (float) * m);

   	for (i = 0; i < m; i++){
    		invertida[i] = malloc (sizeof (float) * m);
	}
	for(i =0;i<m;i++){ // Inicializa a matriz como matriz indentidade
		for(j=0;j<n;j++){
			if(i==j){
				invertida[i][j]=1;			
			}else{
				invertida[i][j]=0;
			}
		}
	}

	for(i = 0; i<m; i++){ // Informa a linha que estou
		c = matriz[i][i];
		if(c==0){
			for(k=i;k<m;k++){
				if(matriz[k][i] > 0){
					for(j=0;j<m;j++){ // Copia a linha da matriz pro vetor
						l1[j] = matriz[k][j];
						inv1[j] = invertida[k][j];
					}
					for(j=0;j<m;j++){ // Copia a linha da matriz pro vetor
						l2[j] = matriz[i][j];
						inv2[j] = invertida[i][j];
					}
					for(j=0;j<m;j++){ // Copia a linha da matriz pro vetor
						matriz[i][j] = l1[j];
						invertida[i][j] = inv1[j];
						matriz[k][j] = l2[j];
						invertida[k][j] = inv2[j];	
					}
				c = matriz[i][i];
				break;
				}
			}
		}
	if(c==0){
		printf("Matriz não inversível\n");
		exit(0);	
	}
		for(j=0;j<n;j++){
			matriz[i][j] = matriz[i][j]/c;
			invertida[i][j] = invertida[i][j]/c;
		}	

		for(j=0;j<n;j++){ // Copia a linha da matriz pro vetor
			l1[j] = matriz[i][j];
			inv1[j] = invertida[i][j];
		}
		for(k=0;k<m;k++){

				for(j=0;j<n;j++){ // Copia a linha da matriz pro vetor
					l2[j] = matriz[k][j];
					inv2[j] = invertida[k][j];
				}
			
		
			a=l2[i];
			b=l1[i];
			pivo = a/b; // Fator que zera a linha abaixo ou acima
			pivo = -pivo;
			if(k!=i){
				for(p=0;p<n;p++){ 
					matriz[k][p] = pivo*l1[p] + matriz[k][p];
				}
				for(p=0;p<n;p++){ 
					invertida[k][p] = pivo*inv1[p] + invertida[k][p];
				}

		}	
		}
		
		}	// Termina o laço i

	

	return invertida;
}




int* simplex(int m1,int n1,int m2,int n2,int tamcb,int tamcn,float** invertida,float** matriznaobase,float** cn,float** cb,int** cnumero,float** b,int* base){

	int i=0,j=0,a=1,baseasair=0,baseaentrar=0,flag=0,aux=0,k=0,basequeprecisaentrar=0,flag2=0; 
	float min=99999999;
	float multiplicada[m1][n1]; 
	float multiplicada2[m1][n2]; 
	float multiplicada3[m1][n2]; 
	float multiplicada4[m1][n2]; 
	float multiplicada5[m1][n2]; 
 	
	printf("\n");
	float teste[a][n1];
	for(i=0;i<m1;i++){	// inicializa com 0		
		for(j=0;j<n2;j++){		
			multiplicada[i][j] = 0;
			multiplicada2[i][j] = 0;
			multiplicada3[i][j] = 0;
			multiplicada4[i][j] = 0;
			multiplicada5[i][j] = 0;
		}
	}	

	for(i=0;i<m1;i++){	// multiplica a matriz
		for(j=0;j<n2;j++){
			for(k=0;k<tamcb;k++){
				multiplicada[i][j]= multiplicada[i][j] + (cb[i][k] * invertida[k][j]);
				multiplicada3[i][j]= multiplicada3[i][j] + (cb[i][k] * invertida[k][j]);
			}
		}
	}

	for(i=0;i<m1;i++){	// inicializa com 0		
		for(j=0;j<n2;j++){		
			multiplicada2[i][j] = 0;
		}
	}	

	for(i=0;i<m1;i++){	// multiplica a matriz
		for(j=0;j<n2;j++){
			for(k=0;k<n1;k++){
				multiplicada2[i][j]= multiplicada2[i][j] + (multiplicada[i][k] * matriznaobase[k][j]);
			}
		}
	}

	for(i=0;i<n2;i++){
		multiplicada[0][i] = multiplicada2[0][i]-cn[0][i];
	}
	
	

	//Onde verifico se a base é ótima
	for(i=0;i<n2;i++){
		if(multiplicada[0][i] < 0){

			printf("\nEsta base não é ótima, o X(%d) precisa entrar\n",cnumero[0][i]+1);
			basequeprecisaentrar = cnumero[0][i];
			baseasair=i;
			flag=1;
			break;
		}
	}
	if(flag==0){
		printf("Esta base é ótima e o valor máximo dela é: \n");
		for(i=0;i<m1;i++){	// multiplica a matriz
			for(j=0;j<n2;j++){
				for(k=0;k<tamcb;k++){
					multiplicada4[i][j]= multiplicada4[i][j] + ( cb[i][k] * invertida[k][j]);

				}
			}
		}

		for(i=0;i<m1;i++){	// multiplica a matriz
			for(j=0;j<n2;j++){
				for(k=0;k<tamcb;k++){
					multiplicada5[i][j]= multiplicada5[i][j] + ( multiplicada4[i][k] * b[k][j]);

				}
			}
		}
		printf("%f\n",multiplicada5[0][0]*max);
		base[0] = -1;
		return base;
	}
	for(i=0;i<m1;i++){	// inicializa com 0		
		for(j=0;j<n2;j++){		
			multiplicada[i][j] = 0;
		}
	}	

	for(i=0;i<m1;i++){	// multiplica a matriz
		for(j=0;j<n2;j++){
			for(k=0;k<tamcb;k++){
				multiplicada[i][j]= multiplicada[i][j] + (invertida[i][k] * b[k][j]);
			}
		}
	}
	for(i=0;i<a;i++){	// inicializa com 0		
		for(j=0;j<n2;j++){		
			multiplicada2[i][j] = 0;
		}
	}

	for(i=0;i<m1;i++){	// multiplica a matriz
		for(j=0;j<n2;j++){
			for(k=0;k<n1;k++){
				multiplicada2[i][j]= multiplicada2[i][j] + (invertida[i][k] * matriznaobase[k][j]);
			}
		}
	}

	for(i=0;i<m1;i++){	// printa a matriz
		for(j=0;j<n2;j++){		
			if(j != baseasair){
				multiplicada2 [i][j]=0;
			}else{ // Coloca todos os valores negativos pois a conta é b⁻¹b - b⁻¹N
				multiplicada2[i][j] = -multiplicada2[i][j];		
			}
		}
	}


	

	for(i=0;i<m1;i++){	// printa a matriz
		for(j=0;j<n2;j++){		
			if(multiplicada2[i][j] != 0){

				multiplicada [i][0] = multiplicada[i][0]/-multiplicada2[i][j];
							
			}	
		}
	}

//	printf("\n------Matriz mulitplicada---------");
//		for(i=0;i<m1;i++){	// printa a matriz
//				printf("%f ",multiplicada [i][0]);
//		}
	flag2=0;
	for(i=0;i<m1;i++){
		if(multiplicada[i][0] >= 0){
			if(multiplicada[i][0] < min){
				flag2 = 1;
				min = multiplicada[i][0];
			} 					
		}
	}

	for(i=0;i<m1;i++){
		if(multiplicada[i][0] == min){
			baseasair = i;
			break;					
		}
	}
	if(flag2==0){
		printf("Este problema tem uma solução ilimitada\n");
		exit(0);
	}

	printf("A base que deve entrar é %d\n",basequeprecisaentrar+1);
	base[baseasair] = basequeprecisaentrar;
	for(i=0;i<m1-1;i++){ // Organiza o vetor bem em ordem crescente
		if(base[i]>base[i+1]){
			aux = base[i];
			base[i] = base[i+1];
			base[i+1] = aux;
		}
	}
	printf("A prórima base é (%d,%d)\n",base[0]+1,base[1]+1);
	sleep(1);
	return base;

}


int* escolhaBase(int m,int n,float** matriz, float** b,int *base){
	
	int ajuste=0,i=0,j=0,flag1=0,k=0,count=0,flagf=0,u=0,flag=0;
	int p=0,t=0,y=0;
	float pivo=0,a=0,bx=0,cx=0;
	float l1[m];
	float l2[m];
	float inv1[m];
	float inv2[m];
	int neterno = n;
	int meterno = m;
	int mreal = sizeof(base)/sizeof(base[0]);

	
	float **invertida; 
  	invertida = malloc (sizeof (float *) * m);

   	for (i = 0; i < m; ++i){
    		invertida[i] = malloc (sizeof (float) * m);
	}
	float **matrizbase; 
  	matrizbase = malloc (m * sizeof (float *));
   	for (i = 0; i < m; ++i)
    		matrizbase[i] = malloc (m * sizeof (float));



	int **cnumero; 
  	 cnumero = malloc ((n-m-m) * sizeof (float *));
   	for (i = 0; i < m; ++i)
    	  cnumero[i] = malloc (1 * sizeof (float));


	float **matrizg; 
  	matrizg = malloc (m * sizeof (float *));
   	for (i = 0; i < m; ++i)
    		matrizg[i] = malloc ((n) * sizeof (float));


	float **c; 
  	 c	 = malloc ((n+m) * sizeof (float *));
   	for (i = 0; i < m; ++i)
   	  c[i] = malloc (1 * sizeof (float));


	float **matrizInvertida; 
  	matrizInvertida = malloc (m * sizeof (float *));
   	for (i = 0; i < m; ++i)
    		matrizInvertida[i] = malloc (m * sizeof (float));


	float **matriznaobase; 
  	matriznaobase = malloc (m * sizeof (float *));
   	for (i = 0; i < m; ++i)
    		matriznaobase[i] = malloc ((n)* sizeof (float));

	float **cb; 
  	 cb = malloc (m * sizeof (float *));
   	for (i = 0; i < m; ++i)
    	  cb[i] = malloc (1 * sizeof (float));

	float **cn; 
  	 cn = malloc ((n-m) * sizeof (float *));
   	for (i = 0; i < m; ++i)
    	  cn[i] = malloc (1 * sizeof (float));

	for(i = 0; i < n;i++){
		if(i < n-m){
			c[0][i] = 0;
		}else{
			c[0][i] = -1;
		}
	
	}

	for(i=0;i<m;i++){ // Copiando os valores de matriz para matrizg
		for(j=0;j<n;j++){
			matrizg[i][j] = matriz[i][j]; 

		}
	}

	int aux = n-m;
	for(i=0;i<m;i++){
		for(j=n-m;j<n;j++){
			if(j == aux){
				matrizg[i][j] = 1; 
			}else{
				matrizg[i][j] = 0;
			}
		}
	aux++;
	}


	ajuste = 0;
	for(i=0;i<m;i++){ // Monta o vetor cbase
		cb[0][i] = c[0][base[i]]; 
	}

	ajuste=0;
	for(i=0;i<n;i++){ // Monta o vetor cnaobase
		for(j=0;j<m;j++){
			flag = 0;
			if(i == base[j]){			
				break; 
			}else{
				flag=1;
			}
		}
		if(flag == 1){
			cn[0][ajuste] = c[0][i];
			flag=0;
			ajuste++;
		}	
	}	
	

	printf("\n========================= Escolhendo a base==========\n");
	ajuste=0;
	for(i=0;i<m;i++){ // Monta a matriz não básica
		for(j=0;j<n;j++){
			for(k=0;k<m;k++){

				if(j == base[k]){
					flag1 = 1;
					break;
				}

			}
			if(flag1 == 0){
				matriznaobase[i][ajuste] = matrizg[i][j]; // Para preencher a matriz nao básica começando do [0][0]
				ajuste++;
			}
			flag1 = 0;	

		}
			ajuste = 0; // reajustando para [x][0], onde x é a próxima linha	
	}


	ajuste=0;
	flag1 = 0;	
	for(i=0;i<m;i++){ // Monta a matriz basica
		for(j=0;j<n;j++){
			for(k=0;k<m;k++){
				if(j == base[k]){ 	
					//printf("j = %d\n",j);
					flag1 = 1;
					break;
				}
			}
			if(flag1 == 1){
				matrizbase[i][ajuste] = matrizg[i][j];
				ajuste++;			
			}
			flag1 = 0;		
		}
			ajuste = 0;

	}
	ajuste = 0;
	for(i=0;i<n;i++){ // Colocando os índices do cnumero
			for(j=0;j<m;j++){		
				if(base[j] == i){
					flagf=0;
					break;			
				}else{
					flagf=1;
				}
			}

			if(flagf==1){
				cnumero[0][count] = i;
				count++;

			}
		flagf=0;
		}
		ajuste=0;

	for(i =0;i<m;i++){ // Inicializa a matriz como matriz indentidade
		for(j=0;j<m;j++){
			if(i==j){
				invertida[i][j]=1;			
			}else{
				invertida[i][j]=0;
			}
		}
	}

	for(i = 0; i<m; i++){ // Informa a linha que estou
		cx = matrizbase[i][i];
		if(cx==0){
		// Tenta trocar linhas para ligar com o 0
		for(k=i;k<m;k++){
			if(matrizbase[k][i] > 0){
				for(j=0;j<m;j++){ // Copia a linha da matriz pro vetor
					l1[j] = matrizbase[k][j];
					inv1[j] = invertida[k][j];
				}
				for(j=0;j<m;j++){ // Copia a linha da matriz pro vetor
					l2[j] = matrizbase[i][j];
					inv2[j] = invertida[i][j];
				}
				for(j=0;j<m;j++){ // Copia a linha da matriz pro vetor
					matrizbase[i][j] = l1[j];
					invertida[i][j] = inv1[j];
					matrizbase[k][j] = l2[j];
					invertida[k][j] = inv2[j];	
				}
			cx = matrizbase[i][i];
			break;
			}
		}
			if(cx==0){
				printf("Essa matriz não tem inversa, terminando computação porque não tem base viável. Falha ao aplicar o método de duas fases");
				exit(0);
			}		
		}
		for(j=0;j<m;j++){
			matrizbase[i][j] = matrizbase[i][j]/cx;
			invertida[i][j] = invertida[i][j]/cx;
		}

		for(j=0;j<m;j++){ // Copia a linha da matriz pro vetor
			l1[j] = matrizbase[i][j];
			inv1[j] = invertida[i][j];
		}
		for(k=0;k<m;k++){

				for(j=0;j<m;j++){ // Copia a linha da matriz pro vetor
					l2[j] = matrizbase[k][j];
					inv2[j] = invertida[k][j];
				}		

			a=l2[i];
			bx=l1[i];
			pivo = a/bx; // Fator que zera a linha abaixo ou acima
			pivo = -pivo;
			if(k!=i){
				for(p=0;p<m;p++){ 

					matrizbase[k][p] = pivo*l1[p] + matrizbase[k][p];
					//printf("matriibase[%f] = %f + %f",matrizbase[k][p],pivo*l1[p], matrizbase[k][p]);
					
				}
			


				for(p=0;p<m;p++){ 
					invertida[k][p] = pivo*inv1[p] + invertida[k][p];
				}

		}	
		}

		
	}	// Termina o laço i

		int ax = n-m;		
		base = simplex(m,m,m,ax,m,ax,invertida,matriznaobase,cn,cb,cnumero,b,base);
		return base;
}


void dual(int m1,int n1,float **matriz,float **b, float **c){
	int i,j;
	float matrizdual[n1][m1];
	for(i=0; i < n1; i++){
		for(j=0;j<m1;j++){
				matrizdual[i][j] = matriz[j][i];		
		}


	}
	printf("Problema dual:\n");
	if(max == 1){
		printf("min "); 
	}else{
		printf("max ");
	}
	printf("z = ");
	for(i=0;i<m1;i++){
		printf("%f ",b[i][0]);
	}
	printf("\n\n");
	for(i=0; i < n1; i++){
		printf("\n");
		for(j=0;j<m1;j++){
				printf("%f ",matrizdual[i][j]);		
		}
		printf("= %f",c[0][i]);

	}

	
	

}




int main(){
	int n=0,m=0,i=0,j=0,k=0,flag1=0,ajuste=0,flag=0,meterno=0,neterno=0,novabase=0,count=0,flagf=0,flagflag=0,flagff=0;
	scanf("%d",&max);
	scanf("%d",&n);
	scanf("%d",&m);
	meterno = m;
	neterno = n;
	float **c; 
  	 c	 = malloc (n * sizeof (float *));
   	for (i = 0; i < m; ++i)
    	  c[i] = malloc (1 * sizeof (float));

	for(i=0;i<n;i++){	//Le o vetor c
		scanf("%f",&c[0][i]);
	}
	float **invertida;
	float **multiplicada;
	float **matriz; 
  	 matriz = malloc (m * sizeof (float *));
   	for (i = 0; i < m; ++i)
    	  matriz[i] = malloc (n * sizeof (float));


	float **matrizg; 
  	 matriz = malloc (m * sizeof (float *));
   	for (i = 0; i < m; ++i)
    	  matriz[i] = malloc ((n + m)* sizeof (float));// Acrescenta os g1,g2...gN

	float **cb; 
  	 cb = malloc (m * sizeof (float *));
   	for (i = 0; i < m; ++i)
    	  cb[i] = malloc (1 * sizeof (float));

	float **cn; 
  	 cn = malloc ((n-m) * sizeof (float *));
   	for (i = 0; i < m; ++i)
    	  cn[i] = malloc (1 * sizeof (float));


	int **cnumero; 
  	 cnumero = malloc ((n-m) * sizeof (float *));
   	for (i = 0; i < m; ++i)
    	  cnumero[i] = malloc (1 * sizeof (float));


	float **b; 
  	 b = malloc (1 * sizeof (float *));
   	for (i = 0; i < m; ++i)
    	  b[i] = malloc ((m) * sizeof (float));


	int *base; 
  	 base = malloc (m * sizeof (int *));


	float **matrizbase; 
  	matrizbase = malloc (m * sizeof (float *));
   	for (i = 0; i < m; ++i)
    		matrizbase[i] = malloc (m * sizeof (float));
	


	float **matriznaobase; 
  	matriznaobase = malloc (m * sizeof (float *));
   	for (i = 0; i < m; ++i)
    		matriznaobase[i] = malloc ((n-m)* sizeof (float)); // Modifiquei de -2 para -m para ficar mais generalista
	
	for(i=0;i<m;i++){	// Le a matriz
		for(j=0;j<n;j++){		
			scanf("%f",&matriz[i][j]);
		}
	}

	for(i=0;i<m;i++){ // Le o vetor b
		scanf("%f",&b[i][0]);			
	}



	for(i=0;i<m;i++){// inicializa a base com base aleatória;
		base[i]=i+n;
	}
	dual(m,n,matriz,b,c);
	if(max == -1){ // Muda os valores de C depedendo se é máximizar ou minimizar
		for(i=0;i<n;i++){		
			c[0][i] = -c[0][i]; 
		}	
	}

	for(;;){
		if(flagff == 0){
			flagff = 0;
			base = escolhaBase(meterno,neterno+meterno,matriz,b,base); //Para quando implementar a base viável
			for(i = 0; i < m;i++){		
				if(base[i] < n){
					flagff = 1;

				}else{
					flagff = 0;
					break;
				}

			}

		}else{
			break;
		}	
	}//exit(0);
	printf("\n------------------Término da escolha da base-----------------\n");
	//exit(0);
//=============================A partir daqui o simplex pode se repetir=========================
printf("---------Começando o simplex a partir da base encontrada----------------------------\n");
for(;;){
		ajuste=0;
		for(i=0;i<m;i++){ // Monta a matriz não básica
			for(j=0;j<n;j++){
				for(k=0;k<m;k++){
					if(j == base[k]){
						flag1 = 1;
						break;
					}
				}
				if(flag1 == 0){
					matriznaobase[i][ajuste] = matriz[i][j]; // Para preencher a matriz nao básica começando do [0][0]
					ajuste++;
				}
				flag1 = 0;	

			}
				ajuste = 0; // reajustando para [x][0], onde x é a próxima linha	
		}


		ajuste=0;
		flag1 = 0;	
		for(i=0;i<m;i++){ // Monta a matriz basica
			for(j=0;j<n;j++){
				for(k=0;k<m;k++){
					if(j == base[k]){ 	
						flag1 = 1;
						break;
					}
				}
				if(flag1 == 1){
					matrizbase[i][ajuste] = matriz[i][j];
					ajuste++;			
				}
				flag1 = 0;		
			}
				ajuste = 0;
		
		}
		ajuste = 0;
		for(i=0;i<m;i++){ // Monta o vetor cbase
			cb[0][i] = c[0][base[i]]; 
		}
		count = 0;
		for(i=0;i<n;i++){ // Colocando os índices do cn
			for(j=0;j<m;j++){		
				if(base[j] == i){
					flagf=0;
					break;			
				}else{
					flagf=1;
				}
			}

			if(flagf==1){
				cnumero[0][count] = i;
				count++;

			}
		flagf=0;
		}
		ajuste=0;
		for(i=0;i<n;i++){ // Monta o vetor cnaobase
			for(j=0;j<m;j++){
				flag = 0;
				if(i == base[j]){			
					break; 
				}else{
					flag=1;
				}
			}
			if(flag == 1){
				cn[0][ajuste] = c[0][i];
				flag=0;
				ajuste++;
			}	
		}	


		invertida = inverte(m,m,matrizbase);

		int a = neterno-meterno;
		base = simplex(meterno,meterno,meterno,a,meterno,a,invertida,matriznaobase,cn,cb,cnumero,b,base);
		if(base[0] == -1){
			return 0;
		}
	}
}
